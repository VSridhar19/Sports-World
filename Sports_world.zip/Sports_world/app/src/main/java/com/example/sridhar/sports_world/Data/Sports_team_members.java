package com.example.sridhar.sports_world.Data;

import android.os.Parcel;
import android.os.Parcelable;

public class Sports_team_members  implements Parcelable {
    String idPlayer;
    String IdTeam;
    String Nationality;
    String Player;
    String Team;
    String Sports;
    String BornDay;
    String BirthLocation;
    String description;
    String Gender;
    String Thumb;

    public Sports_team_members(Parcel in) {
        idPlayer = in.readString();
        IdTeam = in.readString();
        Nationality = in.readString();
        Player = in.readString();
        Team = in.readString();
        Sports = in.readString();
        BornDay = in.readString();
        BirthLocation = in.readString();
        description = in.readString();
        Gender = in.readString();
        Thumb = in.readString();
    }

    public static final Creator<Sports_team_members> CREATOR = new Creator<Sports_team_members>() {
        @Override
        public Sports_team_members createFromParcel(Parcel in) {
            return new Sports_team_members(in);
        }

        @Override
        public Sports_team_members[] newArray(int size) {
            return new Sports_team_members[size];
        }
    };

    public Sports_team_members() {

    }

    public String getIdPlayer() {
        return idPlayer;
    }

    public void setIdPlayer(String idPlayer) {
        this.idPlayer = idPlayer;
    }

    public String getIdTeam() {
        return IdTeam;
    }

    public void setIdTeam(String idTeam) {
        IdTeam = idTeam;
    }

    public String getNationality() {
        return Nationality;
    }

    public void setNationality(String nationality) {
        Nationality = nationality;
    }

    public String getPlayer() {
        return Player;
    }

    public void setPlayer(String player) {
        Player = player;
    }

    public String getTeam() {
        return Team;
    }

    public void setTeam(String team) {
        Team = team;
    }

    public String getSports() {
        return Sports;
    }

    public void setSports(String sports) {
        Sports = sports;
    }

    public String getBornDay() {
        return BornDay;
    }

    public void setBornDay(String bornDay) {
        BornDay = bornDay;
    }

    public String getBirthLocation() {
        return BirthLocation;
    }

    public void setBirthLocation(String birthLocation) {
        BirthLocation = birthLocation;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public String getGender() {
        return Gender;
    }

    public void setGender(String gender) {
        Gender = gender;
    }

    public String getThumb() {
        return Thumb;
    }

    public void setThumb(String thumb) {
        Thumb = thumb;
    }

    @Override
    public int describeContents() {
        return 0;
    }

    @Override
    public void writeToParcel(Parcel parcel, int i) {
        parcel.writeString(idPlayer);
        parcel.writeString(IdTeam);
        parcel.writeString(Nationality);
        parcel.writeString(Player);
        parcel.writeString(Team);
        parcel.writeString(Sports);
        parcel.writeString(BornDay);
        parcel.writeString(BirthLocation);
        parcel.writeString(description);
        parcel.writeString(Gender);
        parcel.writeString(Thumb);
    }
}
