package com.example.sridhar.sports_world;

import android.content.Context;
import android.content.Intent;
import android.net.Uri;
import android.support.annotation.NonNull;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import com.example.sridhar.sports_world.Data.Sports_Teams;
import com.example.sridhar.sports_world.LiveData.Data_Base;
import com.squareup.picasso.Picasso;

import java.util.List;

public class Teams_Adapter extends RecyclerView.Adapter<Teams_Adapter.MyHolder> {
    Context context;
    List<Sports_Teams>lists;
    int i;
    public Teams_Adapter(Teams_Display teams_display, List<Sports_Teams> teams_list) {
        this.context=teams_display;
        this.lists=teams_list;
    }

    @NonNull
    @Override
    public MyHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        return new MyHolder(LayoutInflater.from(parent.getContext()).inflate(R.layout.teams_details,parent,false));
    }

    @Override
    public void onBindViewHolder(@NonNull MyHolder holder, int position) {
        Uri uri=Uri.parse(String.valueOf(lists.get(position).getBanner()));
        Picasso.with(context).load(uri).into(holder.imageView);
        holder.textView1.setText(lists.get(position).getTeam_Name());
        holder.textView2.setText(lists.get(position).getFormed_year());
        holder.textView3.setText(lists.get(position).getWebsite());
        holder.textView4.setText(lists.get(position).getDescription());

    }

    @Override
    public int getItemCount() {
        return lists.size();
    }

    public class MyHolder extends RecyclerView.ViewHolder implements View.OnClickListener {
        TextView textView1,textView2,textView3,textView4;
        ImageView imageView;
        public MyHolder(View itemView) {
            super(itemView);
            textView1 = itemView.findViewById(R.id.TEAM_NAME);
            textView2 = itemView.findViewById(R.id.FORMED_YEAR);
            textView3 = itemView.findViewById(R.id.WEBSITE);
            textView4 = itemView.findViewById(R.id.DEACRIPTION);
            imageView = itemView.findViewById(R.id.Banner);
            itemView.setOnClickListener(this);
        }

        @Override
        public void onClick(View view) {
            Intent intent=new Intent(context,Team_Members.class);
            intent.putExtra("Data1",lists.get(getAdapterPosition()));
            context.startActivity(intent);
        }
    }
}
