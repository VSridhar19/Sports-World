package com.example.sridhar.sports_world.LiveData;

import android.app.Application;
import android.arch.lifecycle.AndroidViewModel;
import android.arch.lifecycle.LiveData;
import android.support.annotation.NonNull;

import com.example.sridhar.sports_world.Data.Sports_main;

import java.util.List;

public class Room_DataBase extends AndroidViewModel {
    private LiveData<List<Sports_main>> listTeamData;
    public Room_DataBase(@NonNull Application application) {
        super(application);
        Data_Base dataBase = Data_Base.getdatabase(this.getApplication());
        listTeamData = dataBase.daoAccess().moviesdata();
    }
    public LiveData<List<Sports_main>> getList() {
        return listTeamData;
    }
}
