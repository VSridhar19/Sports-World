package com.example.sridhar.sports_world;

import android.content.Intent;
import android.os.Parcelable;
import android.support.design.widget.CoordinatorLayout;
import android.support.v4.widget.DrawerLayout;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.GridLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.LinearLayout;
import android.widget.Spinner;
import android.widget.Toast;

import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;
import com.example.sridhar.sports_world.Data.Sports_main;
import com.example.sridhar.sports_world.Widget.Widget1;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.List;

public class MainActivity extends AppCompatActivity implements AdapterView.OnItemSelectedListener {
    Spinner spinner;
    RecyclerView recyclerView;
    String s;
    private RequestQueue queue;
    DrawerLayout drawerLayout;
    //ActionBarDrawerToggle toggle;
    private CoordinatorLayout Layout;
    private LinearLayout linearLayout;
    List<Sports_main> countrys_dataList;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        spinner = findViewById(R.id.spinner);
        recyclerView = findViewById(R.id.rec3);
        drawerLayout=findViewById(R.id.d1);
        Layout=findViewById(R.id.Cordanation_layoutl);
        linearLayout=findViewById(R.id.Liner_layout);
        checkInternet();

        if(savedInstanceState!=null)
        {

            checkInternet();

        }







    }

    private void checkInternet() {

        MyInternetAsyntask asyntask=new MyInternetAsyntask(this);
        asyntask.execute();
        ArrayAdapter<CharSequence> adapter = ArrayAdapter.createFromResource(this, R.array.countrys, android.R.layout.simple_spinner_item);
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spinner.setOnItemSelectedListener(this);

    }

    @Override
    public void onItemSelected(AdapterView<?> adapterView, View view, int i, long l) {
        String search = adapterView.getItemAtPosition(i).toString();
        Countrys_Url("https://www.thesportsdb.com/api/v1/json/1/search_all_leagues.php?c="+search+"");
    }

    private void Countrys_Url(String s) {
       // Toast.makeText(MainActivity.this, "hh"+s, Toast.LENGTH_SHORT).show();

        final StringRequest request = new StringRequest(s, new Response.Listener<String>() {
            @Override
            public void onResponse(String response) {
               countrys_dataList = new ArrayList<>();
                try {
                    JSONObject object = new JSONObject(response);
                    JSONArray array = object.getJSONArray("countrys");
                    Toast.makeText(MainActivity.this, "hh"+array.length(), Toast.LENGTH_SHORT).show();
                    for (int i = 0; i < array.length(); i++) {
                        JSONObject object1 = array.getJSONObject(i);
                        Sports_main country = new Sports_main();
                        country.setId_Team(object1.getString("idLeague"));
                        country.setFormed_year(object1.getString("intFormedYear"));
                        country.setData_of_Formed(object1.getString("dateFirstEvent"));
                        country.setGender(object1.getString("strGender"));
                        country.setSport(object1.getString("strSport"));
                        country.setLeages(object1.getString("strLeague"));
                        country.setDescription(object1.getString("strDescriptionEN"));
                        country.setBadge(object1.getString("strBadge"));
                        country.setLogo(object1.getString("strLogo"));
                        country.setFanarts1(object1.getString("strFanart1"));
                        countrys_dataList.add(country);
                        //  Toast.makeText(MainActivity.this, "m" + countrys_dataList.size(), Toast.LENGTH_SHORT).show();
                    }
                    SetupRecycleView_Countrys(countrys_dataList);
                } catch (JSONException e) {
                    e.printStackTrace();
                }
            }
        }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {

            }
        });
        queue = Volley.newRequestQueue(MainActivity.this);
        queue.add(request);
    }

    private void SetupRecycleView_Countrys(List<Sports_main> countrys_dataList) {
        recyclerView.setLayoutManager(new GridLayoutManager(this,2));
        recyclerView.setAdapter(new Countrys_Adapter(this, countrys_dataList));
    }

    @Override
    public void onNothingSelected(AdapterView<?> adapterView) {

    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.settings_menu, menu);
        return super.onCreateOptionsMenu(menu);
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        int id = item.getItemId();
        if (id == R.id.settings) {
            return true;
        }
        return super.onOptionsItemSelected(item);
    }

    public void settings(MenuItem item) {
        Intent intent = new Intent(MainActivity.this, Favorats_Activity.class);
        startActivity(intent);
    }

    public void feedback(MenuItem item) {
        Intent intent=new Intent(MainActivity.this,FeedBack.class);
        startActivity(intent);
    }

    @Override
    protected void onSaveInstanceState(Bundle outState) {
        super.onSaveInstanceState(outState);
        outState.putParcelableArrayList("key1", (ArrayList<? extends Parcelable>) countrys_dataList);
    }
}
