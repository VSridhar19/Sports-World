package com.example.sridhar.sports_world.Data;

import android.annotation.SuppressLint;
import android.arch.persistence.room.Entity;
import android.arch.persistence.room.PrimaryKey;
import android.os.Parcel;
import android.os.Parcelable;
import android.support.annotation.NonNull;
@Entity(tableName = "Teamsdata")
@SuppressLint("ParcelCreator")
public class Sports_main implements Parcelable {
    @NonNull
    @PrimaryKey
    String id_Team;
    String Formed_year;
    String Data_of_Formed;
    String Gender;
    String Sport;
    String Leages;
    String Badge;
    String Logo;
    String Poster;
    String Fanarts1;
    String Description;

    public Sports_main(Parcel in) {
        id_Team = in.readString();
        Formed_year = in.readString();
        Data_of_Formed = in.readString();
        Gender = in.readString();
        Sport = in.readString();
        Leages = in.readString();
        Badge = in.readString();
        Logo = in.readString();
        Poster = in.readString();
        Fanarts1 = in.readString();
        Description = in.readString();
    }

    public static final Creator<Sports_main> CREATOR = new Creator<Sports_main>() {
        @Override
        public Sports_main createFromParcel(Parcel in) {
            return new Sports_main(in);
        }

        @Override
        public Sports_main[] newArray(int size) {
            return new Sports_main[size];
        }
    };

    public Sports_main() {

    }

    @NonNull
    public String getId_Team() {
        return id_Team;
    }

    public void setId_Team(@NonNull String id_Team) {
        this.id_Team = id_Team;
    }

    public String getFormed_year() {
        return Formed_year;
    }

    public void setFormed_year(String formed_year) {
        Formed_year = formed_year;
    }

    public String getData_of_Formed() {
        return Data_of_Formed;
    }

    public void setData_of_Formed(String data_of_Formed) {
        Data_of_Formed = data_of_Formed;
    }

    public String getGender() {
        return Gender;
    }

    public void setGender(String gender) {
        Gender = gender;
    }

    public String getSport() {
        return Sport;
    }

    public void setSport(String sport) {
        Sport = sport;
    }

    public String getLeages() {
        return Leages;
    }

    public void setLeages(String leages) {
        Leages = leages;
    }

    public String getBadge() {
        return Badge;
    }

    public void setBadge(String badge) {
        Badge = badge;
    }

    public String getLogo() {
        return Logo;
    }

    public void setLogo(String logo) {
        Logo = logo;
    }

    public String getPoster() {
        return Poster;
    }

    public void setPoster(String poster) {
        Poster = poster;
    }

    public String getFanarts1() {
        return Fanarts1;
    }

    public void setFanarts1(String fanarts1) {
        Fanarts1 = fanarts1;
    }

    public String getDescription() {
        return Description;
    }

    public void setDescription(String description) {
        Description = description;
    }

    @Override
    public int describeContents() {
        return 0;
    }

    @Override
    public void writeToParcel(Parcel parcel, int i) {
        parcel.writeString(id_Team);
        parcel.writeString(Formed_year);
        parcel.writeString(Data_of_Formed);
        parcel.writeString(Gender);
        parcel.writeString(Sport);
        parcel.writeString(Leages);
        parcel.writeString(Badge);
        parcel.writeString(Logo);
        parcel.writeString(Poster);
        parcel.writeString(Fanarts1);
        parcel.writeString(Description);
    }
}
