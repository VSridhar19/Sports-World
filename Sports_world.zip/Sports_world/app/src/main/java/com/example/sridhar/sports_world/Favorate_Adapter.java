package com.example.sridhar.sports_world;

import android.content.Context;
import android.content.Intent;
import android.net.Uri;
import android.support.annotation.NonNull;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;

import com.example.sridhar.sports_world.Data.Sports_main;
import com.squareup.picasso.Picasso;

import java.util.List;

public class Favorate_Adapter extends RecyclerView.Adapter<Favorate_Adapter.MyHolder> {
    Context context;
    List<Sports_main> list;
    public Favorate_Adapter(Favorats_Activity favorats_activity, List<Sports_main> countrys_dataList) {
        this.context=favorats_activity;
        this.list=countrys_dataList;
    }

    @NonNull
    @Override
    public MyHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        return new MyHolder(LayoutInflater.from(parent.getContext()).inflate(R.layout.adapter_main,parent,false));
    }

    @Override
    public void onBindViewHolder(@NonNull MyHolder holder, int position) {
        Uri uri=Uri.parse(String.valueOf(list.get(position).getBadge()));
        Picasso.with(context).load(uri).placeholder(R.drawable.refrash).into(holder.imageView);

    }

    @Override
    public int getItemCount() {
        return list.size();
    }

    public class MyHolder extends RecyclerView.ViewHolder implements View.OnClickListener {
        ImageView imageView;
        public MyHolder(View itemView) {
            super(itemView);
            imageView=itemView.findViewById(R.id.Banner);
            imageView.setOnClickListener(this);
        }

        @Override
        public void onClick(View view) {
            Intent intent=new Intent(context,Countrys_Display.class);
            intent.putExtra("Data",list.get(getAdapterPosition()));
            context.startActivity(intent);

        }
    }
}
