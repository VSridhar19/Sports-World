package com.example.sridhar.sports_world;

import android.app.AlertDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.os.AsyncTask;
import android.widget.Toast;

class MyInternetAsyntask extends AsyncTask<String,Void,Boolean> {

    MainActivity activity;
    public MyInternetAsyntask(MainActivity mainActivity) {
        activity=mainActivity;
    }

    @Override
    protected Boolean doInBackground(String... strings) {

      Boolean b=connectvityInfor();


        return b;
    }

    private Boolean connectvityInfor() {


        ConnectivityManager manager= (ConnectivityManager) activity.getSystemService(Context.CONNECTIVITY_SERVICE);
        if (manager!=null)
        {
            NetworkInfo info=manager.getActiveNetworkInfo();
            if (info!=null)
            {
                if (info.getState()==NetworkInfo.State.CONNECTED)
                {
                    return true;
                }
            }
        }
        return false;
    }


    @Override
    protected void onPostExecute(Boolean aBoolean) {
        super.onPostExecute(aBoolean);

        if (aBoolean)
        {
            Toast.makeText(activity, "connected", Toast.LENGTH_SHORT).show();
        }
        else {
           // Toast.makeText(activity, "not connected", Toast.LENGTH_SHORT).show();
            AlertDialog alertDialog = new AlertDialog.Builder(activity).create();

            alertDialog.setTitle(activity.getString(R.string.infos));
            alertDialog.setMessage(activity.getString(R.string.message));
            alertDialog.setIcon(android.R.drawable.ic_dialog_alert);
            alertDialog.setCancelable(false);
            alertDialog.setButton(activity.getString(R.string.ok), new DialogInterface.OnClickListener() {
                public void onClick(DialogInterface dialog, int which) {
                    activity.finish();

                }
            });

            alertDialog.show();


        }
    }
}
