package com.example.sridhar.sports_world;

import android.support.design.widget.CoordinatorLayout;
import android.support.design.widget.Snackbar;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.view.MenuItem;
import android.widget.Button;
import android.widget.Toast;

import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;
import com.example.sridhar.sports_world.Data.Sports_Teams;
import com.example.sridhar.sports_world.Data.Sports_main;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.List;

public class Teams_Display extends AppCompatActivity {
    StatefulRecyclerView recyclerView;
    Sports_main countrys_data;
    List<Sports_Teams> teams_List = new ArrayList<>();
   // List<Seasons_List> seasons_lists=new ArrayList<>();
    private RequestQueue queue;
    int like=0;
    CoordinatorLayout layout;
    Button button;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_teams__display);
        recyclerView=findViewById(R.id.Teams_Recycle);
        // button=findViewById(R.id.favorite);
        layout=findViewById(R.id.Co_Layout);
        countrys_data = new Sports_main();
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        String b = getIntent().getStringExtra("getData");
        getSnackBar();
        TeamsUrl_Display("https://www.thesportsdb.com/api/v1/json/1/lookup_all_teams.php?id=" + b);
    }

    private void getSnackBar() {
        Snackbar snackbar=Snackbar.make(layout,"GAMES IN PARTICULAR COUNTRYS",Snackbar.LENGTH_LONG);
        snackbar.show();
    }

    private void TeamsUrl_Display(String s) {
        final StringRequest request = new StringRequest(s, new Response.Listener<String>() {
            @Override
            public void onResponse(String response) {
                try {
                    JSONObject object = new JSONObject(response);
                    JSONArray array = object.getJSONArray("teams");
                    // Toast.makeText(Teams_Display.this, "totall" + array.length(), Toast.LENGTH_SHORT).show();
                    for (int i = 0; i < array.length(); i++) {
                        JSONObject object1 = array.getJSONObject(i);
                        Sports_Teams list = new Sports_Teams();
                        list.setId(object1.getString("idTeam"));
                        list.setTeam_Name(object1.getString("strTeam"));
                        list.setBanner(object1.getString("strTeamBadge"));
                        list.setFormed_year(object1.getString("intFormedYear"));
                        list.setDescription(object1.getString("strStadiumDescription"));
                        list.setWebsite(object1.getString("strWebsite"));
                        teams_List.add(list);
                        //Toast.makeText(Teams_Display.this, "full"+teams_List.size(), Toast.LENGTH_SHORT).show();
                    }
                    setRecycleTeams(teams_List);
                } catch (JSONException e) {
                    e.printStackTrace();
                }
            }
        }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {

            }
        });
        queue = Volley.newRequestQueue(Teams_Display.this);
        queue.add(request);
    }

    private void setRecycleTeams(List<Sports_Teams> teams_list) {
        recyclerView.setLayoutManager(new LinearLayoutManager(this));
        recyclerView.setAdapter(new Teams_Adapter(this, teams_list));

    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {

        if(item.getItemId()==android.R.id.home)
        {
            finish();
        }
        return super.onOptionsItemSelected(item);
    }
}
