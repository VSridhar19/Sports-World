package com.example.sridhar.sports_world.Widget;

import android.content.Intent;
import android.widget.RemoteViewsService;

public class Widget2 extends RemoteViewsService {
    @Override
    public RemoteViewsFactory onGetViewFactory(Intent intent) {
        return (RemoteViewsFactory) new MyWidgetRemoteFactor(this.getApplicationContext(),intent);
    }
}
