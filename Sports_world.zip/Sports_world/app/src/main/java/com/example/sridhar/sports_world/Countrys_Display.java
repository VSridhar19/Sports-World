package com.example.sridhar.sports_world;

import android.content.Intent;
import android.support.design.widget.CoordinatorLayout;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import com.example.sridhar.sports_world.Data.Sports_main;
import com.example.sridhar.sports_world.LiveData.Data_Base;
import com.example.sridhar.sports_world.Widget.Widget1;
import com.google.android.gms.ads.AdRequest;
import com.google.android.gms.ads.AdView;
import com.google.android.gms.ads.MobileAds;
import com.squareup.picasso.Picasso;

import java.util.ArrayList;
import java.util.List;

public class Countrys_Display extends AppCompatActivity implements View.OnClickListener {
    ImageView imageView1,imageView2;
    TextView t1,t2,t3,t4,t5,t6;
    Button button;
    String string;
    Data_Base data_base;
    private AdView mAdView;
    int i=0;
    CoordinatorLayout layout;
    List<Sports_main> listw;
    Sports_main countrys_data;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_countrys__display);
        imageView1=findViewById(R.id.main_imageView);
        imageView2=findViewById(R.id.smallimage);
        MobileAds.initialize(this, "ca-app-pub-3940256099942544~3347511713");
        mAdView = findViewById(R.id.adView);
        AdRequest adRequest = new AdRequest.Builder().build();
        mAdView.loadAd(adRequest);
        t1=findViewById(R.id.SPORT_NAME);
        t2=findViewById(R.id.GENDER);
        t3=findViewById(R.id.DATE_OF_FORMED);
        t4=findViewById(R.id.FARMED_YEARS);
        t5=findViewById(R.id.LEAGUE);
        t6=findViewById(R.id.DESCRIPTION);
        button=findViewById(R.id.Favorates);
        layout=findViewById(R.id.Coordination_layout);
        data_base=Data_Base.getdatabase(this.getApplicationContext());
        countrys_data=new Sports_main();
        listw=new ArrayList<>();
        countrys_data=getIntent().getParcelableExtra("Data");
        listw=getIntent().getParcelableArrayListExtra("w");
       // Toast.makeText(this, "widget"+listw, Toast.LENGTH_SHORT).show();
        t1.setText(countrys_data.getSport());
        t2.setText(countrys_data.getGender());
        t3.setText(countrys_data.getData_of_Formed());
        t4.setText(countrys_data.getData_of_Formed());
        t5.setText(countrys_data.getLeages());
        t6.setText(countrys_data.getDescription());
        Picasso.with(getApplicationContext()).load(countrys_data.getFanarts1()).into(imageView1);
        Picasso.with(getApplicationContext()).load(countrys_data.getBadge()).into(imageView2);
        string=String.valueOf(countrys_data.getId_Team());
        Sports_main c=data_base.daoAccess().countyies(string);
        if(c!=null){
            button.setBackgroundResource(R.drawable.ic_star_black_24dp);
            i=1;
        }else{
            button.setBackgroundResource(R.drawable.ic_star_border_black_24dp);
            i=0;}
        button.setOnClickListener(this);
    }

    public void FAB(View view) {
        Intent intent=new Intent(this,Teams_Display.class);
        intent.putExtra("getData",countrys_data.getId_Team());
        startActivity(intent);
    }



    @Override
    public void onClick(View view) {
        if(i==0){
            button.setBackgroundResource(R.drawable.ic_star_black_24dp);
            Sports_main c1=data_base.daoAccess().countyies(string);
            if(c1==null){
                data_base.daoAccess().insertData(countrys_data);
            }
            Toast.makeText(getApplicationContext(), R.string.movieadd, Toast.LENGTH_SHORT).show();
            i=1;
        }else {
            button.setBackgroundResource(R.drawable.ic_star_border_black_24dp);
            data_base.daoAccess().Remove(countrys_data);
            Toast.makeText(getApplicationContext(), R.string.moviewremove, Toast.LENGTH_SHORT).show();
            i=0;
        }

    }

    @Override
    public void onPointerCaptureChanged(boolean hasCapture) {

    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.widget_menu, menu);
        return super.onCreateOptionsMenu(menu);

    }

    public void widget(MenuItem item) {

        Widget1.sendRefreshBroadcast(this,listw);
        Toast.makeText(this, getString(R.string.widget)+listw, Toast.LENGTH_SHORT).show();
    }
}

