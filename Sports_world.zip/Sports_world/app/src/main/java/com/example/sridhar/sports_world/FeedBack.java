package com.example.sridhar.sports_world;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;

import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

public class FeedBack extends AppCompatActivity {
    DatabaseReference databaseReference;
    EditText editText;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_feed_back);
        editText=findViewById(R.id.ed1);
        databaseReference=FirebaseDatabase.getInstance().getReference("getdata");
    }

    public void submit(View view) {

        String s=databaseReference.push().getKey();
        databaseReference.child(s).setValue(editText.getText().toString());
    }
}
