package com.example.sridhar.sports_world;

import android.content.Context;
import android.net.Uri;
import android.support.annotation.NonNull;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import com.example.sridhar.sports_world.Data.Sports_team_members;
import com.squareup.picasso.Picasso;

import java.util.List;

public class Members_adapter extends RecyclerView.Adapter<Members_adapter.MyHolder> {
    Context context;
    List<Sports_team_members> list;
    public Members_adapter(Team_Members team_members, List<Sports_team_members> team_members1) {
        this.context=team_members;
        this.list=team_members1;



    }

    @NonNull
    @Override
    public MyHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        return new MyHolder(LayoutInflater.from(parent.getContext()).inflate(R.layout.member_details,parent,false));
    }

    @Override
    public void onBindViewHolder(@NonNull MyHolder holder, int position) {
        Uri uri=Uri.parse(String.valueOf(list.get(position).getThumb()));
        Picasso.with(context).load(uri).into(holder.imageView);
        holder.textView1.setText(list.get(position).getPlayer());
        holder.textView3.setText(list.get(position).getBornDay());
        holder.textView4.setText(list.get(position).getBirthLocation());
        holder.textView5.setText(list.get(position).getDescription());

    }

    @Override
    public int getItemCount() {
        return list.size();
    }

    public class MyHolder extends RecyclerView.ViewHolder {
        TextView textView1,textView2,textView3,textView4,textView5;
        ImageView imageView;
        public MyHolder(View itemView) {
            super(itemView);
            textView1=itemView.findViewById(R.id.PLAYER_NAME);
            textView3=itemView.findViewById(R.id.BORN_DATE);
            textView4=itemView.findViewById(R.id.BORN_LOCATION);
            textView5=itemView.findViewById(R.id.DEACRIPTION);
            imageView=itemView.findViewById(R.id.Thumb);
        }
    }
}
