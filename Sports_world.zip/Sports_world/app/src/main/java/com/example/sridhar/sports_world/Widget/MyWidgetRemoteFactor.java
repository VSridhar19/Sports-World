package com.example.sridhar.sports_world.Widget;

import android.content.Context;
import android.content.Intent;
import android.database.Cursor;
import android.widget.RemoteViews;
import android.widget.RemoteViewsService;

import com.example.sridhar.sports_world.R;

import static com.example.sridhar.sports_world.Widget.Widget1.list1;

public class MyWidgetRemoteFactor implements RemoteViewsService.RemoteViewsFactory {
    private Context context;
    private Cursor cursor;

    public MyWidgetRemoteFactor(Context applicationContext, Intent intent) {
        context = applicationContext;

    }

    @Override
    public void onCreate() {

    }

    @Override
    public void onDataSetChanged() {

    }

    @Override
    public void onDestroy() {

    }

    @Override
    public int getCount() {
        return list1==null ? 0:list1.size();
    }

    @Override
    public RemoteViews getViewAt(int i) {
        RemoteViews rv = new RemoteViews(context.getPackageName(), R.layout.home_widget2);
        rv.setTextViewText(R.id.widgetItemTaskNameLabel, list1.get(i).getSport());
        return rv;

    }

    @Override
    public RemoteViews getLoadingView() {
        return null;
    }

    @Override
    public int getViewTypeCount() {
        return 1;
    }

    @Override
    public long getItemId(int i) {
        return i;
    }

    @Override
    public boolean hasStableIds() {
        return true;
    }


}