package com.example.sridhar.sports_world.Data;

import android.os.Parcel;
import android.os.Parcelable;

public class Sports_Teams  implements Parcelable {
    String id;
    String Team_Name;
    String Formed_year;
    String Description;
    String Website;
    String Banner;

    public Sports_Teams(Parcel in) {
        id = in.readString();
        Team_Name = in.readString();
        Formed_year = in.readString();
        Description = in.readString();
        Website = in.readString();
        Banner = in.readString();
    }

    public static final Creator<Sports_Teams> CREATOR = new Creator<Sports_Teams>() {
        @Override
        public Sports_Teams createFromParcel(Parcel in) {
            return new Sports_Teams(in);
        }

        @Override
        public Sports_Teams[] newArray(int size) {
            return new Sports_Teams[size];
        }
    };

    public Sports_Teams() {

    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getTeam_Name() {
        return Team_Name;
    }

    public void setTeam_Name(String team_Name) {
        Team_Name = team_Name;
    }

    public String getFormed_year() {
        return Formed_year;
    }

    public void setFormed_year(String formed_year) {
        Formed_year = formed_year;
    }

    public String getDescription() {
        return Description;
    }

    public void setDescription(String description) {
        Description = description;
    }

    public String getWebsite() {
        return Website;
    }

    public void setWebsite(String website) {
        Website = website;
    }

    public String getBanner() {
        return Banner;
    }

    public void setBanner(String banner) {
        Banner = banner;
    }

    @Override
    public int describeContents() {
        return 0;
    }

    @Override
    public void writeToParcel(Parcel parcel, int i) {
        parcel.writeString(id);
        parcel.writeString(Team_Name);
        parcel.writeString(Formed_year);
        parcel.writeString(Description);
        parcel.writeString(Website);
        parcel.writeString(Banner);
    }
}
