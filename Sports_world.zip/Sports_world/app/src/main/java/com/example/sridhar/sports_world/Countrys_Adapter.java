package com.example.sridhar.sports_world;

import android.content.Context;
import android.content.Intent;
import android.net.Uri;
import android.os.Parcelable;
import android.support.annotation.NonNull;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.Toast;

import com.example.sridhar.sports_world.Data.Sports_main;
import com.example.sridhar.sports_world.Widget.Widget1;
import com.squareup.picasso.Picasso;

import java.util.ArrayList;
import java.util.List;

public class Countrys_Adapter extends RecyclerView.Adapter<Countrys_Adapter.MyHolder> {
    Context context;
    List<Sports_main> list;
    public Countrys_Adapter(MainActivity mainActivity, List<Sports_main> countrys_dataList) {
        this.context=mainActivity;
        this.list=countrys_dataList;

    }

    @NonNull
    @Override
    public MyHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        return new MyHolder(LayoutInflater.from(parent.getContext()).inflate(R.layout.adapter_main,parent,false));
    }

    @Override
    public void onBindViewHolder(@NonNull MyHolder holder, int position) {
        Uri uri=Uri.parse(String.valueOf(list.get(position).getBadge()));
        Picasso.with(context).load(uri).placeholder(R.drawable.games).into(holder.images_views);
       // Toast.makeText(context, context.getString(R.string.getting)+list.size(), Toast.LENGTH_SHORT).show();

    }

    @Override
    public int getItemCount() {
        return list.size();
    }

    public class MyHolder extends RecyclerView.ViewHolder implements View.OnClickListener {
        ImageView images_views;
        public MyHolder(View itemView) {
            super(itemView);
            //Widget1.sendRefreshBroadcast(context,list);
            images_views=itemView.findViewById(R.id.Banner);
            itemView.setOnClickListener(this);
        }

        @Override
        public void onClick(View view) {
            Intent intent=new Intent(context,Countrys_Display.class);
            intent.putExtra("Data",list.get(getAdapterPosition()));
            intent.putParcelableArrayListExtra("w", (ArrayList<? extends Parcelable>) list);
            context.startActivity(intent);
        }
    }
}
