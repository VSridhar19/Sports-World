package com.example.sridhar.sports_world.LiveData;

import android.arch.lifecycle.LiveData;
import android.arch.persistence.room.Dao;
import android.arch.persistence.room.Delete;
import android.arch.persistence.room.Insert;
import android.arch.persistence.room.Query;

import com.example.sridhar.sports_world.Data.Sports_main;

import java.util.List;
@Dao
public interface Dao_acess {
    @Insert
    void insertData(Sports_main favorate_data);
    @Query("SELECT * FROM Teamsdata")
    LiveData<List<Sports_main>> moviesdata();
    @Query("SELECT * FROM Teamsdata WHERE id_Team LIKE :id")
    Sports_main countyies(String id);
    @Delete
    void Remove(Sports_main data);
}
