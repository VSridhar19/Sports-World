package com.example.sridhar.sports_world.LiveData;

import android.arch.persistence.room.Database;
import android.arch.persistence.room.Room;
import android.arch.persistence.room.RoomDatabase;
import android.content.Context;

import com.example.sridhar.sports_world.Data.Sports_main;

@Database(entities = {Sports_main.class},version = 7,exportSchema = false)
public  abstract class Data_Base extends RoomDatabase {
    public static final String DATABASE_NAME="fav.db";
    private static Data_Base favorate;
    private static final Object LOCK = new Object();
    public static Data_Base getdatabase(Context context) {
        if(favorate == null){
            synchronized (LOCK){
                favorate = Room.databaseBuilder(context.getApplicationContext(),
                        Data_Base.class, Data_Base.DATABASE_NAME)
                        .allowMainThreadQueries()
                        .fallbackToDestructiveMigration()
                        .build();
            }
        }
        return favorate;
    }
    public abstract Dao_acess daoAccess();
}
