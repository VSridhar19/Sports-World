package com.example.sridhar.sports_world;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.view.View;
import android.widget.TextView;
import android.widget.Toast;

import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;
import com.example.sridhar.sports_world.Data.Sports_Teams;
import com.example.sridhar.sports_world.Data.Sports_team_members;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.List;

public class Team_Members extends AppCompatActivity {
    StatefulRecyclerView recyclerView;
    TextView textView;
    Sports_Teams team_list;
    List<Sports_team_members> team_members = new ArrayList<>();
    private RequestQueue queue;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_team__members);
        recyclerView = findViewById(R.id.TeamMember_recycle);
        textView=findViewById(R.id.TextView);
        team_list = new Sports_Teams();
        team_list = getIntent().getParcelableExtra("Data1");
        // Toast.makeText(this, "members" + team_list, Toast.LENGTH_SHORT).show();
        TeamUrlMembers("https://www.thesportsdb.com/api/v1/json/1/lookup_all_players.php?id=" + team_list.getId() + "");
    }

    private void TeamUrlMembers(String s) {
        final StringRequest request = new StringRequest(s, new Response.Listener<String>() {
            @Override
            public void onResponse(String response) {
                try {
                    JSONObject object = new JSONObject(response);
                    JSONArray array = object.getJSONArray("player");
                    // Toast.makeText(Team_Members.this, "lost" + array.length(), Toast.LENGTH_SHORT).show();
                    for (int i = 0; i < array.length(); i++) {
                        JSONObject object1 = array.getJSONObject(i);
                        Sports_team_members id = new Sports_team_members();
                        id.setPlayer(object1.getString("strPlayer"));
                        id.setBornDay(object1.getString("dateBorn"));
                        id.setBirthLocation(object1.getString("strBirthLocation"));
                        id.setTeam(object1.getString("strTeam"));
                        id.setSports(object1.getString("strSport"));
                        id.setDescription(object1.getString("strDescriptionEN"));
                        id.setThumb(object1.getString("strThumb"));
                        team_members.add(id);
                        //  Toast.makeText(Team_Members.this, "comming" + team_members.size(), Toast.LENGTH_SHORT).show();

                    }
                    if (team_members.size() == 0) {
                        recyclerView.setVisibility(View.GONE);
                        textView.setVisibility(View.VISIBLE);
                    } else {
                        recyclerView.setVisibility(View.VISIBLE);
                        textView.setVisibility(View.GONE);
                        setRecycleView(team_members);

                    }
                    //
                } catch (JSONException e) {
                    e.printStackTrace();
                }
            }
        }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {

            }
        });
        queue = Volley.newRequestQueue(Team_Members.this);
        queue.add(request);
    }

    private void setRecycleView(List<Sports_team_members> team_members) {
        recyclerView.setLayoutManager(new LinearLayoutManager(this));
        recyclerView.setAdapter(new Members_adapter(this, team_members));
    }
}
