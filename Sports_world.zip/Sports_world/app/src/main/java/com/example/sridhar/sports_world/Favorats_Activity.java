package com.example.sridhar.sports_world;

import android.arch.lifecycle.Observer;
import android.arch.lifecycle.ViewModelProviders;
import android.support.annotation.Nullable;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.GridLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.widget.Toast;

import com.example.sridhar.sports_world.Data.Sports_main;
import com.example.sridhar.sports_world.LiveData.Room_DataBase;

import java.util.ArrayList;
import java.util.List;

public class Favorats_Activity extends AppCompatActivity {
    StatefulRecyclerView recyclerView;
    List<Sports_main> countrys_dataList;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_favorats_);
        recyclerView = findViewById(R.id.Favotites_Recycle);
        countrys_dataList = new ArrayList<>();
        getFav();
    }

    private void getFav() {
        if (countrys_dataList != null) {
            countrys_dataList.clear();
            final Room_DataBase room_dataBase = ViewModelProviders.of(this).get(Room_DataBase.class);
            room_dataBase.getList().observe(Favorats_Activity.this, new Observer<List<Sports_main>>() {
                @Override
                public void onChanged(@Nullable List<Sports_main> sports_mains) {
                    countrys_dataList = sports_mains;
                    setRecycleView(countrys_dataList);

                }
            });
        }
    }

    private void setRecycleView(List<Sports_main> countrys_dataList) {
        recyclerView.setLayoutManager(new GridLayoutManager(this,2));
        // recyclerView.setAdapter(new Countrys_Adapter(this, countrys_dataList));
      //  Toast.makeText(this, "fav"+countrys_dataList.size(), Toast.LENGTH_SHORT).show();
        recyclerView.setAdapter(new Favorate_Adapter(this,countrys_dataList));
    }
}
